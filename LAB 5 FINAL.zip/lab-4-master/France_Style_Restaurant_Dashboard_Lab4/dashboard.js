const menu=[
{name:"Beef Steak",sku:"INV-001",cat:"Main Course",price:420,qty:18},
{name:"Seafood Pasta",sku:"INV-002",cat:"Main Course",price:360,qty:6},
{name:"Grilled Chicken",sku:"INV-003",cat:"Main Course",price:280,qty:24},
{name:"Chef Special Burger",sku:"INV-004",cat:"Main Course",price:225,qty:0},
{name:"Fresh Juice",sku:"INV-005",cat:"Beverage",price:120,qty:9},
{name:"Iced Tea",sku:"INV-006",cat:"Beverage",price:95,qty:22},
{name:"Chocolate Cake",sku:"INV-007",cat:"Dessert",price:260,qty:4},
{name:"French Fries",sku:"INV-008",cat:"Side Dish",price:150,qty:15},
{name:"Garlic Bread",sku:"INV-009",cat:"Side Dish",price:120,qty:3},
{name:"Caesar Salad",sku:"INV-010",cat:"Appetizer",price:220,qty:10}
];
let orders=[
{id:1,table:"Table 03",customer:"Walk-in",items:["Beef Steak","French Fries"],status:"Preparing"},
{id:2,table:"Table 05",customer:"Ms. Santos",items:["Seafood Pasta","Fresh Juice"],status:"Pending"},
{id:3,table:"Table 01",customer:"Mr. Cruz",items:["Grilled Chicken","Iced Tea"],status:"Served"}
];
let reservations=[{date:"2026-09-08",time:"19:00",guests:2,table:"Table 01"}];
let cart=[];
let salesChart,valueChart;
const peso=n=>new Intl.NumberFormat("en-PH",{style:"currency",currency:"PHP",maximumFractionDigits:0}).format(n);
const status=x=>x.qty===0?["Out of Stock","out"]:x.qty<=5?["Low Stock","low"]:["In Stock","in"];

function toast(msg){document.querySelector("#toastArea").innerHTML=`<div class="toast-msg">${msg}</div>`;setTimeout(()=>document.querySelector("#toastArea").innerHTML="",2200)}
function setupCategories(){const s=document.querySelector("#catFilter");[...new Set(menu.map(x=>x.cat))].sort().forEach(c=>s.innerHTML+=`<option value="${c}">${c}</option>`)}
function filteredMenu(){
 const q=document.querySelector("#search").value.toLowerCase(),c=document.querySelector("#catFilter").value,s=document.querySelector("#statusFilter").value;
 const min=+document.querySelector("#minPrice").value||0,max=+document.querySelector("#maxPrice").value||Infinity;
 return menu.filter(x=>{const st=status(x)[1];return (x.name.toLowerCase().includes(q)||x.sku.toLowerCase().includes(q))&&(c==="all"||x.cat===c)&&(s==="all"||s===st)&&x.price>=min&&x.price<=max})
}
function renderMenu(){
 const data=filteredMenu(),low=menu.filter(x=>x.qty<=5);
 document.querySelector("#stockAlert").innerHTML=low.length?`<div class="alert-box"><strong>⚠ Stock alert:</strong> ${low.map(x=>`${x.name} (${x.qty})`).join(", ")} need attention.</div>`:"";
 document.querySelector("#menuTable").innerHTML=data.length?data.map(x=>{const [label,key]=status(x);return `<tr><td><strong>${x.name}</strong><div class="sku">${x.sku}</div></td><td>${x.cat}</td><td>${peso(x.price)}</td><td>${x.qty}</td><td><span class="status ${key}">${label}</span></td><td>${peso(x.price*x.qty)}</td></tr>`}).join(""):`<tr><td colspan="6" class="text-center text-secondary py-4">No matching items.</td></tr>`;
}
function renderOrders(){
 document.querySelector("#orderCount").textContent=`${orders.length} order(s)`;
 document.querySelector("#ordersList").innerHTML=orders.map(o=>{let total=o.items.reduce((a,n)=>{let x=menu.find(m=>m.name===n);return a+(x?x.price:0)},0);return `<div class="order-card"><h3>${o.table}</h3><p><strong>Customer / Staff:</strong> ${o.customer}</p><p><strong>Ordered Items:</strong></p><div class="order-items">${o.items.map(i=>`• ${i}`).join("<br>")}</div><div class="order-total">Total Bill: ${peso(total)}</div><div class="order-actions"><select class="form-select form-select-sm order-status" data-id="${o.id}"><option ${o.status==="Pending"?"selected":""}>Pending</option><option ${o.status==="Preparing"?"selected":""}>Preparing</option><option ${o.status==="Served"?"selected":""}>Served</option></select><button class="outline-btn remove-order" data-id="${o.id}">Remove</button></div></div>`}).join("");
 document.querySelectorAll(".order-status").forEach(s=>s.onchange=e=>{orders.find(o=>o.id==e.target.dataset.id).status=e.target.value;renderSales();toast("Order status updated")});
 document.querySelectorAll(".remove-order").forEach(b=>b.onclick=()=>{orders=orders.filter(o=>o.id!=b.dataset.id);renderOrders();renderSales();toast("Order removed")});
}
function renderReservations(){
 document.querySelector("#reservationList").innerHTML=reservations.length?reservations.map((r,i)=>`<div class="reservation"><div><strong>${r.table}</strong><br><small>${r.date} • ${r.time} • ${r.guests} guest(s)</small></div><button class="outline-btn remove-res" data-id="${i}">Remove</button></div>`).join(""):`<p class="text-secondary small">No reservations scheduled.</p>`;
 document.querySelectorAll(".remove-res").forEach(b=>b.onclick=()=>{reservations.splice(+b.dataset.id,1);renderReservations();toast("Reservation removed")});
}
function renderSales(){
 const inv=menu.reduce((a,x)=>a+x.price*x.qty,0),served=orders.filter(x=>x.status==="Served").length;
 document.querySelector("#totalSales").textContent=peso(orders.reduce((a,o)=>a+o.items.reduce((s,n)=>s+(menu.find(x=>x.name===n)?.price||0),0),0));
 document.querySelector("#served").textContent=served;document.querySelector("#invValue").textContent=peso(inv);
 if(salesChart)salesChart.destroy();salesChart=new Chart(document.querySelector("#salesChart"),{type:"bar",data:{labels:["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep"],datasets:[{label:"Sales",data:[32000,38500,42000,39800,46500,51000,54800,59200,63400],borderRadius:3}]},options:{responsive:true,plugins:{legend:{display:false}}}});
 const cats={};menu.forEach(x=>cats[x.cat]=(cats[x.cat]||0)+x.price*x.qty);
 if(valueChart)valueChart.destroy();valueChart=new Chart(document.querySelector("#valueChart"),{type:"bar",data:{labels:Object.keys(cats),datasets:[{label:"Inventory Value",data:Object.values(cats),borderRadius:3}]},options:{responsive:true,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true,ticks:{callback:v=>"₱"+v.toLocaleString()}}}}});
}
function fillOrderItems(){const select=document.querySelector("#orderItems"),current=select.value;select.innerHTML=menu.filter(x=>x.qty>0).map(x=>`<option value="${x.name}">${x.name} - ${peso(x.price)}</option>`).join("");if([...select.options].some(o=>o.value===current))select.value=current}
function fillStockItems(){document.querySelector("#stockItem").innerHTML=menu.map(x=>`<option value="${x.name}">${x.name} (${x.qty} available)</option>`).join("")}
function renderCart(){const total=cart.reduce((sum,item)=>sum+item.price*item.quantity,0);document.querySelector("#cartTotal").textContent=peso(total);document.querySelector("#orderCart").innerHTML=cart.length?cart.map(item=>`<div class="cart-item"><div class="cart-item-details"><strong>${item.name}</strong><small>${peso(item.price)} each</small></div><div class="cart-item-controls"><span class="cart-quantity">${item.quantity}</span><button type="button" class="cart-remove" data-name="${item.name}" aria-label="Remove ${item.name}">&times;</button></div></div>`).join(""):`<p class="empty-cart">Your cart is empty.</p>`;document.querySelector("#addOrderBtn").disabled=!cart.length}
function exportCSV(){const rows=[["Product","SKU","Category","Unit Price","Quantity","Status","Value"],...menu.map(x=>[x.name,x.sku,x.cat,x.price,x.qty,status(x)[0],x.price*x.qty])];const csv=rows.map(r=>r.map(v=>`"${String(v).replaceAll('"','""')}"`).join(",")).join("\\n");const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([csv],{type:"text/csv"}));a.download="restaurant_inventory.csv";a.click();toast("CSV exported")}
const loginPage=document.querySelector("#loginPage"),dashboardApp=document.querySelector("#dashboardApp"),loginForm=document.querySelector("#loginForm"),loginError=document.querySelector("#loginError");
loginForm.onsubmit=e=>{e.preventDefault();const username=document.querySelector("#loginUsername").value,password=document.querySelector("#loginPassword").value;if(username!=="France"||password!=="123"){loginError.hidden=false;return}loginError.hidden=true;loginPage.hidden=true;dashboardApp.hidden=false;renderSales()};
document.querySelectorAll(".nav-btn").forEach(b=>b.onclick=()=>{document.querySelectorAll(".nav-btn").forEach(x=>x.classList.remove("active"));b.classList.add("active");document.querySelectorAll(".page").forEach(p=>p.classList.remove("active"));document.querySelector("#"+b.dataset.page).classList.add("active");if(b.dataset.page==="sales")renderSales()});
["search","catFilter","statusFilter","minPrice","maxPrice"].forEach(id=>{document.querySelector("#"+id).addEventListener("input",renderMenu);document.querySelector("#"+id).addEventListener("change",renderMenu)});
document.querySelector("#addToCartBtn").onclick=()=>{const name=document.querySelector("#orderItems").value,item=menu.find(x=>x.name===name);if(!item||item.qty<1)return toast("That item is out of stock");const cartItem=cart.find(x=>x.name===name);if(cartItem)cartItem.quantity++;else cart.push({name:item.name,price:item.price,quantity:1});item.qty--;renderCart();renderMenu();fillOrderItems();fillStockItems();toast(`${item.name} added to cart`)};
document.querySelector("#orderCart").onclick=e=>{const button=e.target.closest(".cart-remove");if(!button)return;const item=cart.find(x=>x.name===button.dataset.name);const stockItem=menu.find(x=>x.name===button.dataset.name);if(item&&stockItem)stockItem.qty+=item.quantity;cart=cart.filter(x=>x.name!==button.dataset.name);renderCart();renderMenu();fillOrderItems();fillStockItems()};
document.querySelector("#addOrderBtn").onclick=()=>{const table=document.querySelector("#orderTable").value.trim()||"Table 01",customer=document.querySelector("#orderCustomer").value.trim()||"Walk-in",items=cart.flatMap(item=>Array(item.quantity).fill(item.name));if(!items.length)return toast("Add at least one item to the cart");orders.push({id:Date.now(),table,customer,items,status:document.querySelector("#orderStatus").value});cart=[];renderCart();renderOrders();renderSales();toast("Order added to list")};
document.querySelector("#addResBtn").onclick=()=>{const date=document.querySelector("#resDate").value,time=document.querySelector("#resTime").value;if(!date||!time)return toast("Please enter date and time");reservations.push({date,time,guests:+document.querySelector("#resGuests").value,table:document.querySelector("#resTable").value});renderReservations();toast("Reservation added")};
document.querySelector("#addMenuBtn").onclick=()=>{const name=document.querySelector("#newName").value.trim(),sku=document.querySelector("#newSku").value.trim()||"INV-"+String(menu.length+1).padStart(3,"0"),cat=document.querySelector("#newCat").value.trim()||"Main Course",price=+document.querySelector("#newPrice").value,qty=+document.querySelector("#newQty").value;if(!name||!price)return toast("Enter product name and price");menu.push({name,sku,cat,price,qty});renderMenu();fillOrderItems();fillStockItems();setupCategories();toast("Menu item added")};
document.querySelector("#addStockBtn").onclick=()=>{const item=menu.find(x=>x.name===document.querySelector("#stockItem").value),quantity=+document.querySelector("#stockQty").value;if(!item||quantity<1)return toast("Enter a valid stock quantity");item.qty+=quantity;document.querySelector("#stockQty").value="";renderMenu();fillOrderItems();fillStockItems();toast(`${quantity} ${item.name} added to stock`)};
document.querySelector("#exportBtn").onclick=exportCSV;
document.querySelector("#logoutBtn").onclick=()=>{dashboardApp.hidden=true;loginPage.hidden=false;loginForm.reset();loginError.hidden=true;document.querySelector("#loginUsername").focus()};
setupCategories();fillOrderItems();fillStockItems();renderCart();renderMenu();renderOrders();renderReservations();
setInterval(()=>{menu.forEach(x=>{if(Math.random()<.08)x.qty=Math.max(0,x.qty+(Math.random()>.5?1:-1))});renderMenu();fillOrderItems()},10000);
